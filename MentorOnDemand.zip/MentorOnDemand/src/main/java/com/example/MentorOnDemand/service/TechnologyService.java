package com.example.MentorOnDemand.service;

import java.util.List;

import com.example.MentorOnDemand.model.Technology;

public interface TechnologyService {

	void insertTechnology(Technology technology);

	Object getTechnology();

	Object getTechnologyList();

	Object getTechnologyById(int id);

	//List<Technology> findById(int id);

	
}
